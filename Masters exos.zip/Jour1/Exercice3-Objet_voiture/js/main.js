const maVoiture = {
    marque: "Ford Mustang",
    annee: 1995,
    achat: "20 mai 2020",
    passagers: ["Antoine", "Elon Musk", "Kim Jong", "Erdogan", "Ramzan Kadyrov"]
}

document.write(`<p>Ma voiture est une: ${maVoiture.marque} de ${maVoiture.annee} que j'ai acheté le ${maVoiture.achat}</p>`)
document.write("<p>Ma liste de passagers est: </p>")
//document.write(`<ul><li>${maVoiture.passagers[0]}</li><li>${maVoiture.passagers[1]}</li><li>${maVoiture.passagers[2]}</li><li>${maVoiture.passagers[3]}</li><li>${maVoiture.passagers[4]}</li></ul>`)


document.write("<ul>")

//tu pars de l'index 0, tu parcours le tableau tant que tu n'es pas au bout de sa longueure, passe au tour de boucle suivant, il va comprendre i < 5 = 5 tours de boucles

for(let i=0; i < maVoiture.passagers.length; i++){
    document.write(`<li>${maVoiture.passagers[i]}</li>`)
}

maVoiture.passagers.forEach(passager => document.write(`<li>${passager}</li>`))

document.write("</ul>")