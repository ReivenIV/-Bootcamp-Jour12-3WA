            //    0         1        2         3          4         5          6
const day = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"]
console.log(day)
console.log(day[5])
const month = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"]

//récupération de la date du moment
let date = new Date() //objet qui va nous permettre de manipuler la date du jour
//cet objet possède pleins de propriétés

/*date.getDay() nous retourne 5 (vu qu'on est vendredi) et qu'il part de l'index 0

day[5] = day[date.getDay()]

let date = {
    getDate: 13,
    getDay: function(){
        return 5
    },
    getMonth: function(){
        return 4
    },
    getFullYear: 2022
}


date.getMonth() nous retourne 4 (vu qu'on est mai) et qu'il part de l'index 0

month[4] = month[date.getMonth()]
*/

document.write(`Aujourd'hui, nous sommes le: ${day[date.getDay()]} ${date.getDate()} ${month[date.getMonth()]} ${date.getFullYear()}`)