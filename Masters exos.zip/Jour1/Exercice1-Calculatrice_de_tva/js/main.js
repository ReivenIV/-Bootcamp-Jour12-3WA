const TVA = 20

// Demande le montant HT à l'utilisateur.

let montantHT = parseFloat(prompt("Quel prix mister?"))

//calcule du montant de la TVA appliquée sur le montantHT

let montantTVA = montantHT * TVA / 100 //montantHT * 0.20 marche aussi

//calcul du montant TTC

let montantTTC = montantHT + montantTVA

document.write(`<p>Le montant HT saisi est: ${montantHT}€, la TVA est de ${montantTVA}€, du coup le montant TTC est de ${montantTTC}€!</p>`)